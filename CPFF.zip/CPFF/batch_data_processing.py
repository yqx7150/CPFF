import torch
import numpy as np
import cv2
import torch.nn.functional as F
from torch.fft import fftn, ifftn
import os
from pathlib import Path
import scipy.io  # 用于生成.mat文件

class FZAImageProcessor:
    def __init__(self, di=3, z1=300, LX1=200, dp=0.014, NX=256, NY=256, r1=0.23):
        """
        初始化FZA图像处理器

        参数:
            di: 像距
            z1: 物距
            LX1: 物体宽度(mm)
            dp: 像素尺寸(mm)
            NX, NY: 图像尺寸
            r1: FZA半径(mm)
        """
        self.di = di
        self.z1 = z1
        self.LX1 = LX1
        self.dp = dp
        self.NX = NX
        self.NY = NY
        self.r1 = r1
        self.S = 2 * dp * NX
        self.M = di / z1
        self.ri = (1 + self.M) * r1

        # 初始化传输函数
        self._init_transfer_functions()

        # 设置设备
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def _init_transfer_functions(self):
        """初始化传输函数"""
        fu_max, fv_max = 0.5 / self.dp, 0.5 / self.dp
        du, dv = 2 * fu_max / self.NX, 2 * fv_max / self.NY
        u, v = np.mgrid[-fu_max:fu_max:du, -fv_max:fv_max:dv]
        u = u.T
        v = v.T

        self.H1 = 1j * (np.exp(-1j * (np.dot(np.pi, self.ri ** 2)) * (u ** 2 + v ** 2)))
        self.H3 = 1j * (np.exp(-1j * (np.dot(np.pi, self.ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.5 * np.pi))

        self.MASK1 = np.array(self.H1, dtype=np.complex128)
        self.MASK3 = np.array(self.H3, dtype=np.complex128)

    def fza1(self):
        """生成FZA掩模1"""
        x, y = np.meshgrid(np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)),
                           np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)))
        r_2 = x ** 2 + y ** 2
        mask = 0.5 * (1 + np.cos(np.dot(np.pi, r_2) / self.ri ** 2))
        return mask

    def fza2(self):
        """生成FZA掩模2"""
        x, y = np.meshgrid(np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)),
                           np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)))
        r_2 = x ** 2 + y ** 2
        mask = 0.5 * (1 + np.cos(np.dot(np.pi, r_2) / self.ri ** 2 + 0.5 * np.pi))
        return mask

    def fza3(self):
        """生成FZA掩模3"""
        x, y = np.meshgrid(np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)),
                           np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)))
        r_2 = x ** 2 + y ** 2
        mask = 0.5 * (1 + np.cos(np.dot(np.pi, r_2) / self.ri ** 2 + np.pi))
        return mask

    def fza4(self):
        """生成FZA掩模4"""
        x, y = np.meshgrid(np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)),
                           np.linspace(-self.S / 2, self.S / 2 - self.S / (2 * self.NX), (2 * self.NX)))
        r_2 = x ** 2 + y ** 2
        mask = 0.5 * (1 + np.cos(np.dot(np.pi, r_2) / self.ri ** 2 + 1.5 * np.pi))
        return mask

    def pinhole(self, O, x=0, y=0):
        """
        针孔成像模拟

        参数:
            O: 输入图像(numpy数组)
            x, y: 偏移量
        """
        if O.ndim == 3:  # 如果是彩色图像，则转为灰度图像
            O = cv2.cvtColor((O * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY) / 255.0

        m, n = O.shape
        Ly = m * self.LX1 / n  # 计算物体高度

        Lxi = self.M * self.LX1  # 图像宽度
        Lyi = self.M * Ly  # 图像高度

        # 计算传感器的物理尺寸
        W = self.NX * self.dp
        H = self.NX * self.dp

        # 计算缩放后的物体坐标
        Xs, Ys = np.meshgrid(np.linspace(-Lxi / 2, Lxi / 2, n),
                             np.linspace(-Lyi / 2, Lyi / 2, m))

        # 计算映射的目标坐标
        Xq, Yq = np.meshgrid(np.linspace(-W / 2, W / 2, self.NX),
                             np.linspace(-H / 2, H / 2, self.NX))

        # 归一化坐标 (-1,1)
        Xq_norm = 2 * (Xq - Xs.min()) / (Xs.max() - Xs.min()) - 1
        Yq_norm = 2 * (Yq - Ys.min()) / (Ys.max() - Ys.min()) - 1

        # 生成 PyTorch 张量
        O_tensor = torch.tensor(O, dtype=torch.float32).unsqueeze(0).unsqueeze(0)  # [1, 1, m, n]
        grid = torch.stack((torch.tensor(Xq_norm, dtype=torch.float32),
                            torch.tensor(Yq_norm, dtype=torch.float32)), dim=-1).unsqueeze(0)  # [1, Nx, Nx, 2]

        # 使用 PyTorch 进行插值
        I = F.grid_sample(O_tensor, grid, mode='bilinear', padding_mode='zeros', align_corners=True)

        return I.squeeze().numpy()

    def forward(self, obj, H):
        """前向传播"""
        obj = obj.cpu().numpy()
        FO = np.fft.fftshift(np.fft.fft2(np.fft.fftshift(obj)))
        I = np.fft.fftshift(np.fft.ifft2(np.fft.fftshift(FO * H)))
        I = np.real(I)
        I = np.array(I, dtype=np.float32)
        I = torch.as_tensor(I).to(self.device)
        return I

    def process_single_image(self, img_path, output_dir=None):
        """
        处理单个图像文件

        参数:
            img_path: 输入图像路径
            output_dir: 输出目录(如果为None则不保存)

        返回:
            处理后的图像字典
        """
        # 读取彩色图片
        img = cv2.imread(img_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) / 255.0

        # 分离彩色通道
        R, G, B = img[:, :, 0], img[:, :, 1], img[:, :, 2]

        # 生成每个通道的成像
        ImR = self.pinhole(R)
        ImG = self.pinhole(G)
        ImB = self.pinhole(B)

        # 转换为张量并移动到设备
        ImR = torch.tensor(ImR, dtype=torch.float32).to(self.device)
        ImG = torch.tensor(ImG, dtype=torch.float32).to(self.device)
        ImB = torch.tensor(ImB, dtype=torch.float32).to(self.device)

        # 前向传播
        I1_R = self.forward(ImR, self.MASK1)
        I1_G = self.forward(ImG, self.MASK1)
        I1_B = self.forward(ImB, self.MASK1)

        I3_R = self.forward(ImR, self.MASK3)
        I3_G = self.forward(ImG, self.MASK3)
        I3_B = self.forward(ImB, self.MASK3)

        # 组合RGB图像
        rgb_0 = torch.stack([I1_R, I1_G, I1_B], dim=0).cpu().numpy()
        rgb_0 = np.transpose(rgb_0, (1, 2, 0))  # (H, W, C)
        rgb_0 = (rgb_0 - rgb_0.min()) / (rgb_0.max() - rgb_0.min())
        rgb_0 = np.clip(rgb_0, 0, 1)

        rgb_50 = torch.stack([I3_R, I3_G, I3_B], dim=0).cpu().numpy()
        rgb_50 = np.transpose(rgb_50, (1, 2, 0))  # (H, W, C)
        rgb_50 = (rgb_50 - rgb_50.min()) / (rgb_50.max() - rgb_50.min())
        rgb_50 = np.clip(rgb_50, 0, 1)

        # 保存结果
        if output_dir is not None:
            os.makedirs(output_dir, exist_ok=True)
            img_name = Path(img_path).stem

            cv2.imwrite(os.path.join(output_dir, f'{img_name}_phase0.png'), rgb_0 * 255)
            cv2.imwrite(os.path.join(output_dir, f'{img_name}_phase50.png'), rgb_50 * 255)

        return {
            'phase0': rgb_0,
            'phase50': rgb_50
        }




    #
    # ############################ 单相位 ############################
    # def process_batch(self, input_paths, output_dir, width=96):
    #     """
    #     批量处理图像，为每张图像创建独立子文件夹并生成处理后的图像及.mat文件
    #     （整个mask区域使用边界中心高度的颜色进行纯色填充）
    #
    #     参数:
    #         input_paths: 输入图像路径列表或目录路径
    #         output_dir: 输出根目录
    #         width: 填充宽度（默认96）
    #
    #     返回:
    #         处理结果列表，每个元素为(图像路径, 处理结果状态)的元组
    #     """
    #     # 处理输入路径：如果是目录则获取所有图像文件
    #     if isinstance(input_paths, str):
    #         input_paths = [
    #             os.path.join(input_paths, f)
    #             for f in sorted(os.listdir(input_paths))
    #             if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff'))
    #         ]
    #
    #     results = []
    #     img_index = 1  # 子文件夹序号计数器，从1开始自增
    #
    #     # 图像处理参数
    #     w = width  # mask区域宽度
    #     cut_color = 0  # 颜色裁剪开关
    #
    #     for img_path in input_paths:
    #         try:
    #             # 验证文件存在性
    #             if not os.path.isfile(img_path):
    #                 print(f"跳过非文件路径: {img_path}")
    #                 results.append((img_path, "跳过：非文件路径"))
    #                 continue
    #
    #             # 读取图像并转换色彩空间
    #             img = cv2.imread(img_path)
    #             if img is None:
    #                 print(f"无法读取图像文件: {img_path}")
    #                 results.append((img_path, "失败：无法读取图像"))
    #                 continue
    #
    #             # 获取图像名称（不含扩展名）
    #             img_name = os.path.splitext(os.path.basename(img_path))[0]
    #
    #             # 创建子文件夹：output_dir/img{i}
    #             subfolder = os.path.join(output_dir, f"img{img_index}")
    #             os.makedirs(subfolder, exist_ok=True)
    #             print(f"处理图像: {img_name} -> 保存至 {subfolder}")
    #
    #             # 转换为RGB并归一化
    #             img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) / 255.0
    #
    #             # 分离RGB通道并分别进行针孔成像处理
    #             R, G, B = img_rgb[:, :, 0], img_rgb[:, :, 1], img_rgb[:, :, 2]
    #             ImR = self.pinhole(R)
    #             ImG = self.pinhole(G)
    #             ImB = self.pinhole(B)
    #
    #             # 转换为张量并移动到设备
    #             ImR = torch.tensor(ImR, dtype=torch.float32).to(self.device)
    #             ImG = torch.tensor(ImG, dtype=torch.float32).to(self.device)
    #             ImB = torch.tensor(ImB, dtype=torch.float32).to(self.device)
    #
    #             # 前向传播（使用MASK1和MASK3生成两种相位结果）
    #             I1_R = self.forward(ImR, self.MASK1)
    #             I1_G = self.forward(ImG, self.MASK1)
    #             I1_B = self.forward(ImB, self.MASK1)
    #
    #             I3_R = self.forward(ImR, self.MASK3)
    #             I3_G = self.forward(ImG, self.MASK3)
    #             I3_B = self.forward(ImB, self.MASK3)
    #
    #             # 组合RGB图像并归一化（phase0结果）
    #             rgb_0 = torch.stack([I1_R, I1_G, I1_B], dim=0).cpu().numpy()
    #             rgb_0 = np.transpose(rgb_0, (1, 2, 0))  # (H, W, C)
    #             rgb_0 = (rgb_0 - rgb_0.min()) / (rgb_0.max() - rgb_0.min() + 1e-8)
    #             rgb_0 = np.clip(rgb_0, 0, 1)
    #
    #             # 组合RGB图像并归一化（phase50结果）
    #             rgb_50 = torch.stack([I3_R, I3_G, I3_B], dim=0).cpu().numpy()
    #             rgb_50 = np.transpose(rgb_50, (1, 2, 0))  # (H, W, C)
    #             rgb_50 = (rgb_50 - rgb_50.min()) / (rgb_50.max() - rgb_50.min() + 1e-8)
    #             rgb_50 = np.clip(rgb_50, 0, 1)
    #
    #             # 处理rgb_0：左侧整个w列mask区域使用边界中心高度颜色填充
    #             rgb_0_processed = rgb_0.copy()
    #             rgb_50_processed = rgb_50.copy()
    #
    #             # 保存处理后的图像
    #             processed_50_img_path = os.path.join(subfolder, f'processed_50.png')
    #             cv2.imwrite(processed_50_img_path, cv2.cvtColor(rgb_50_processed * 255, cv2.COLOR_RGB2BGR))
    #
    #             # 保存.mat文件（变量名'ob'）
    #             mat_50_path = os.path.join(subfolder, f'processed_50.mat')
    #             scipy.io.savemat(mat_50_path, {'ob': rgb_50_processed})
    #
    #             # 额外保存原始针孔成像结果
    #             original_img = np.stack([ImR.cpu().numpy(), ImG.cpu().numpy(), ImB.cpu().numpy()], axis=2)
    #             original_img = (original_img - original_img.min()) / (original_img.max() - original_img.min() + 1e-8)
    #             original_save_path = os.path.join(subfolder, f'original.png')
    #             cv2.imwrite(original_save_path, cv2.cvtColor(original_img * 255, cv2.COLOR_RGB2BGR))
    #             original_save_path = os.path.join(subfolder, f'original.mat')
    #             scipy.io.savemat(original_save_path, {'Im': original_img})
    #
    #             results.append((img_path, f"成功：保存至 img{img_index}"))
    #             img_index += 1  # 自增计数器
    #
    #         except Exception as e:
    #             error_msg = f"处理失败: {str(e)}"
    #             print(f"处理 {img_path} 时出错: {error_msg}")
    #             results.append((img_path, error_msg))
    #
    #     return results
    ####################双相位################
    def process_batch(self, input_paths, output_dir, width=96):
        """
        批量处理图像，为每张图像创建独立子文件夹并生成处理后的图像及.mat文件
        （整个mask区域使用边界中心高度的颜色进行纯色填充）

        参数:
            input_paths: 输入图像路径列表或目录路径
            output_dir: 输出根目录
            width: 填充宽度（默认96）

        返回:
            处理结果列表，每个元素为(图像路径, 处理结果状态)的元组
        """
        # 处理输入路径：如果是目录则获取所有图像文件
        if isinstance(input_paths, str):
            input_paths = [
                os.path.join(input_paths, f)
                for f in sorted(os.listdir(input_paths))
                if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff'))
            ]

        results = []
        img_index = 1  # 子文件夹序号计数器，从1开始自增

        # 图像处理参数
        w = width  # mask区域宽度
        cut_color = 0  # 颜色裁剪开关

        for img_path in input_paths:
            try:
                # 验证文件存在性
                if not os.path.isfile(img_path):
                    print(f"跳过非文件路径: {img_path}")
                    results.append((img_path, "跳过：非文件路径"))
                    continue

                # 读取图像并转换色彩空间
                img = cv2.imread(img_path)
                if img is None:
                    print(f"无法读取图像文件: {img_path}")
                    results.append((img_path, "失败：无法读取图像"))
                    continue

                # 获取图像名称（不含扩展名）
                img_name = os.path.splitext(os.path.basename(img_path))[0]

                # 创建子文件夹：output_dir/img{i}
                subfolder = os.path.join(output_dir, f"img{img_index}")
                os.makedirs(subfolder, exist_ok=True)
                print(f"处理图像: {img_name} -> 保存至 {subfolder}")

                # 转换为RGB并归一化
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) / 255.0

                # 分离RGB通道并分别进行针孔成像处理
                R, G, B = img_rgb[:, :, 0], img_rgb[:, :, 1], img_rgb[:, :, 2]
                ImR = self.pinhole(R)
                ImG = self.pinhole(G)
                ImB = self.pinhole(B)

                # 转换为张量并移动到设备
                ImR = torch.tensor(ImR, dtype=torch.float32).to(self.device)
                ImG = torch.tensor(ImG, dtype=torch.float32).to(self.device)
                ImB = torch.tensor(ImB, dtype=torch.float32).to(self.device)

                # 前向传播（使用MASK1和MASK3生成两种相位结果）
                I1_R = self.forward(ImR, self.MASK1)
                I1_G = self.forward(ImG, self.MASK1)
                I1_B = self.forward(ImB, self.MASK1)

                I3_R = self.forward(ImR, self.MASK3)
                I3_G = self.forward(ImG, self.MASK3)
                I3_B = self.forward(ImB, self.MASK3)

                # 组合RGB图像并归一化（phase0结果）
                rgb_0 = torch.stack([I1_R, I1_G, I1_B], dim=0).cpu().numpy()
                rgb_0 = np.transpose(rgb_0, (1, 2, 0))  # (H, W, C)
                rgb_0 = (rgb_0 - rgb_0.min()) / (rgb_0.max() - rgb_0.min() + 1e-8)
                rgb_0 = np.clip(rgb_0, 0, 1)

                # 组合RGB图像并归一化（phase50结果）
                rgb_50 = torch.stack([I3_R, I3_G, I3_B], dim=0).cpu().numpy()
                rgb_50 = np.transpose(rgb_50, (1, 2, 0))  # (H, W, C)
                rgb_50 = (rgb_50 - rgb_50.min()) / (rgb_50.max() - rgb_50.min() + 1e-8)
                rgb_50 = np.clip(rgb_50, 0, 1)

                # 处理rgb_0：左侧整个w列mask区域使用边界中心高度颜色填充
                rgb_0_processed = rgb_0.copy()
                # 获取起点颜色（用于确定边界）
                if cut_color == 1:
                    start_colors_0 = rgb_0[:, w + 1, :].copy()
                else:
                    start_colors_0 = rgb_0[:, 255, :].copy()

                # 计算边界中心高度（图像垂直中点）
                height = rgb_0.shape[0]
                boundary_center_row = height // 2  # 边界中心高度的行索引
                # 获取边界中心高度的颜色（用于整个mask区域填充）
                fill_color_0 = start_colors_0[boundary_center_row]

                # 整个左侧w列mask区域填充为边界中心高度的颜色
                rgb_0_processed[:, :w, :] = fill_color_0

                # 处理rgb_50：右侧整个w列mask区域使用边界中心高度颜色填充
                rgb_50_processed = rgb_50.copy()
                # 获取起点颜色（用于确定边界）
                if cut_color == 1:
                    start_colors_50 = rgb_50[:, -(w + 1), :].copy()
                else:
                    start_colors_50 = rgb_50[:, 0, :].copy()

                # 获取边界中心高度的颜色（用于整个mask区域填充）
                fill_color_50 = start_colors_50[boundary_center_row]

                # 整个右侧w列mask区域填充为边界中心高度的颜色
                rgb_50_processed[:, -w:, :] = fill_color_50

                # 保存处理后的图像
                processed_0_img_path = os.path.join(subfolder, f'processed_0.png')
                cv2.imwrite(processed_0_img_path, cv2.cvtColor(rgb_0_processed * 255, cv2.COLOR_RGB2BGR))

                processed_50_img_path = os.path.join(subfolder, f'processed_50.png')
                cv2.imwrite(processed_50_img_path, cv2.cvtColor(rgb_50_processed * 255, cv2.COLOR_RGB2BGR))

                # 保存.mat文件（变量名'ob'）
                mat_0_path = os.path.join(subfolder, f'processed_0.mat')
                scipy.io.savemat(mat_0_path, {'ob': rgb_0_processed})

                mat_50_path = os.path.join(subfolder, f'processed_50.mat')
                scipy.io.savemat(mat_50_path, {'ob': rgb_50_processed})

                # 额外保存原始针孔成像结果
                original_img = np.stack([ImR.cpu().numpy(), ImG.cpu().numpy(), ImB.cpu().numpy()], axis=2)
                original_img = (original_img - original_img.min()) / (original_img.max() - original_img.min() + 1e-8)
                original_save_path = os.path.join(subfolder, f'original.png')
                cv2.imwrite(original_save_path, cv2.cvtColor(original_img * 255, cv2.COLOR_RGB2BGR))
                original_save_path = os.path.join(subfolder, f'original.mat')
                scipy.io.savemat(original_save_path, {'Im': original_img})

                results.append((img_path, f"成功：保存至 img{img_index}"))
                img_index += 1  # 自增计数器

            except Exception as e:
                error_msg = f"处理失败: {str(e)}"
                print(f"处理 {img_path} 时出错: {error_msg}")
                results.append((img_path, error_msg))

        return results

# 使用示例
if __name__ == "__main__":
    # 初始化处理器
    processor = FZAImageProcessor()

    # 第一个参数：原始图像存放的文件夹
    # 第二个参数：处理完之后的图像存放的文件夹
    # 第三个参数：裁剪宽度
    results = processor.process_batch('./test_imgs/og',
                                      './test_imgs/input',
                                      96)


