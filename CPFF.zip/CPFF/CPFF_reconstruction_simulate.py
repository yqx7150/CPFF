import functools
from tkinter import W
import torch
import numpy as np
import abc
from operator_fza import forward,backward

from models.utils import from_flattened_numpy, to_flattened_numpy, get_score_fn
from scipy import integrate
import sde_lib
from models import utils as mutils
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import cv2
import matplotlib.pyplot as plt
from fza_mask_forward_simulate import fza_mask_forward1, fza_mask_forward2, fza_mask_forward3, fza_mask_forward4
from TV_norm import TVnorm
from tvdenoise import tvdenoise
import scipy.io as io
from math import exp
import torch.nn.functional as F
import torch.fft

_CORRECTORS = {}
_PREDICTORS = {}

def register_predictor(cls=None, *, name=None):
  """A decorator for registering predictor classes."""

  def _register(cls):
    if name is None:
      local_name = cls.__name__
    else:
      local_name = name
    if local_name in _PREDICTORS:
      raise ValueError(f'Already registered model with name: {local_name}')
    _PREDICTORS[local_name] = cls
    return cls

  if cls is None:
    return _register
  else:
    return _register(cls)


def register_corrector(cls=None, *, name=None):
  """A decorator for registering corrector classes."""

  def _register(cls):
    if name is None:
      local_name = cls.__name__
    else:
      local_name = name
    if local_name in _CORRECTORS:
      raise ValueError(f'Already registered model with name: {local_name}')
    _CORRECTORS[local_name] = cls
    return cls

  if cls is None:
    return _register
  else:
    return _register(cls)


def get_predictor(name):
  return _PREDICTORS[name]


def get_corrector(name):
  return _CORRECTORS[name]


def get_sampling_fn(config, sde, shape, inverse_scaler, eps):
  """Create a sampling function.

  Args:
    config: A `ml_collections.ConfigDict` object that contains all configuration information.
    sde: A `sde_lib.SDE` object that represents the forward SDE.
    shape: A sequence of integers representing the expected shape of a single sample.
    inverse_scaler: The inverse data normalizer function.
    eps: A `float` number. The reverse-time SDE is only integrated to `eps` for numerical stability.

  Returns:
    A function that takes random states and a replicated training state and outputs samples with the
      trailing dimensions matching `shape`.
  """

  sampler_name = config.sampling.method
  # Probability flow ODE sampling with black-box ODE solvers
  if sampler_name.lower() == 'ode':
    sampling_fn = get_ode_sampler(sde=sde,
                                  shape=shape,
                                  inverse_scaler=inverse_scaler,
                                  denoise=config.sampling.noise_removal,
                                  eps=eps,
                                  device=config.device)
  # Predictor-Corrector sampling. Predictor-only and Corrector-only samplers are special cases.
  elif sampler_name.lower() == 'pc':
    predictor = get_predictor(config.sampling.predictor.lower())
    corrector = get_corrector(config.sampling.corrector.lower())
    sampling_fn = get_pc_sampler(sde=sde,
                                 shape=shape,
                                 predictor=predictor,
                                 corrector=corrector, inverse_scaler=inverse_scaler, snr=config.sampling.snr,
                                 n_steps=config.sampling.n_steps_each,
                                 probability_flow=config.sampling.probability_flow,
                                 continuous=config.training.continuous, denoise=config.sampling.noise_removal, eps=eps,
                                 device=config.device)
  else:
    raise ValueError(f"Sampler name {sampler_name} unknown.")

  return sampling_fn


class Predictor(abc.ABC):
  """The abstract class for a predictor algorithm."""

  def __init__(self, sde, score_fn, probability_flow=False):
    super().__init__()
    self.sde = sde
    # Compute the reverse SDE/ODE
    self.rsde = sde.reverse(score_fn, probability_flow)
    self.score_fn = score_fn

  @abc.abstractmethod
  def update_fn(self, x, t):
    """One update of the predictor.

    Args:
      x: A PyTorch tensor representing the current state
      t: A Pytorch tensor representing the current time step.

    Returns:
      x: A PyTorch tensor of the next state.
      x_mean: A PyTorch tensor. The next state without random noise. Useful for denoising.
    """
    pass


class Corrector(abc.ABC):
  """The abstract class for a corrector algorithm."""

  def __init__(self, sde, score_fn, snr, n_steps):
    super().__init__()
    self.sde = sde
    self.score_fn = score_fn
    self.snr = snr
    self.n_steps = n_steps

  @abc.abstractmethod
  def update_fn(self, x, t):
    """One update of the corrector.

    Args:
      x: A PyTorch tensor representing the current state
      t: A PyTorch tensor representing the current time step.

    Returns:
      x: A PyTorch tensor of the next state.
      x_mean: A PyTorch tensor. The next state without random noise. Useful for denoising.
    """
    pass


@register_predictor(name='euler_maruyama')
class EulerMaruyamaPredictor(Predictor):
  def __init__(self, sde, score_fn, probability_flow=False):
    super().__init__(sde, score_fn, probability_flow)

  def update_fn(self, x, t):
    dt = -1. / self.rsde.N
    z = torch.randn_like(x)
    drift, diffusion = self.rsde.sde(x, t)
    x_mean = x + drift * dt
    x = x_mean + diffusion[:, None, None, None] * np.sqrt(-dt) * z
    return x, x_mean


@register_predictor(name='reverse_diffusion')
class ReverseDiffusionPredictor(Predictor):
  def __init__(self, sde, score_fn, probability_flow=False):
    super().__init__(sde, score_fn, probability_flow)

  def update_fn(self, x, t):
    f, G = self.rsde.discretize(x, t)
    z = torch.randn_like(x)
    x_mean = x - f
    x = x_mean + G[:, None, None, None] * z
    return x, x_mean


@register_predictor(name='ancestral_sampling')
class AncestralSamplingPredictor(Predictor):
  """The ancestral sampling predictor. Currently only supports VE/VP SDEs."""

  def __init__(self, sde, score_fn, probability_flow=False):
    super().__init__(sde, score_fn, probability_flow)
    if not isinstance(sde, sde_lib.VPSDE) and not isinstance(sde, sde_lib.VESDE):
      raise NotImplementedError(f"SDE class {sde.__class__.__name__} not yet supported.")
    assert not probability_flow, "Probability flow not supported by ancestral sampling"

  def vesde_update_fn(self, x, t):
    sde = self.sde
    timestep = (t * (sde.N - 1) / sde.T).long()
    sigma = sde.discrete_sigmas[timestep]
    adjacent_sigma = torch.where(timestep == 0, torch.zeros_like(t), sde.discrete_sigmas.to(t.device)[timestep - 1])
    score = self.score_fn(x, t)
    x_mean = x + score * (sigma ** 2 - adjacent_sigma ** 2)[:, None, None, None]
    std = torch.sqrt((adjacent_sigma ** 2 * (sigma ** 2 - adjacent_sigma ** 2)) / (sigma ** 2))
    noise = torch.randn_like(x)
    x = x_mean + std[:, None, None, None] * noise
    return x, x_mean

  def vpsde_update_fn(self, x, t):
    sde = self.sde
    timestep = (t * (sde.N - 1) / sde.T).long()
    beta = sde.discrete_betas.to(t.device)[timestep]
    score = self.score_fn(x, t)
    x_mean = (x + beta[:, None, None, None] * score) / torch.sqrt(1. - beta)[:, None, None, None]
    noise = torch.randn_like(x)
    x = x_mean + torch.sqrt(beta)[:, None, None, None] * noise
    return x, x_mean

  def update_fn(self, x, t):
    if isinstance(self.sde, sde_lib.VESDE):
      return self.vesde_update_fn(x, t)
    elif isinstance(self.sde, sde_lib.VPSDE):
      return self.vpsde_update_fn(x, t)


@register_predictor(name='none')
class NonePredictor(Predictor):
  """An empty predictor that does nothing."""

  def __init__(self, sde, score_fn, probability_flow=False):
    pass

  def update_fn(self, x, t):
    return x, x


@register_corrector(name='langevin')
class LangevinCorrector(Corrector):
  def __init__(self, sde, score_fn, snr, n_steps):
    super().__init__(sde, score_fn, snr, n_steps)
    if not isinstance(sde, sde_lib.VPSDE) \
        and not isinstance(sde, sde_lib.VESDE) \
        and not isinstance(sde, sde_lib.subVPSDE):
      raise NotImplementedError(f"SDE class {sde.__class__.__name__} not yet supported.")

  def update_fn(self, x1,x2,x3,x_mean, t):
    ###############
    x1 = x1.float()
    x2 = x2.float()
    x3 = x3.float()
    x_mean = x_mean.float()
    #######################
    sde = self.sde
    score_fn = self.score_fn
    n_steps = self.n_steps
    target_snr = self.snr
    if isinstance(sde, sde_lib.VPSDE) or isinstance(sde, sde_lib.subVPSDE):
      timestep = (t * (sde.N - 1) / sde.T).long()
      alpha = sde.alphas.to(t.device)[timestep]
    else:
      alpha = torch.ones_like(t)

    for i in range(n_steps):
      grad1 = score_fn(x1, t) # 5
      grad2 = score_fn(x2, t) # 5
      grad3 = score_fn(x3, t) # 5

      noise1 = torch.randn_like(x1) # 4
      noise2 = torch.randn_like(x2) # 4
      noise3 = torch.randn_like(x3) # 4

      grad_norm1 = torch.norm(grad1.reshape(grad1.shape[0], -1), dim=-1).mean()
      noise_norm1 = torch.norm(noise1.reshape(noise1.shape[0], -1), dim=-1).mean()
      grad_norm2 = torch.norm(grad2.reshape(grad2.shape[0], -1), dim=-1).mean()
      noise_norm2 = torch.norm(noise2.reshape(noise2.shape[0], -1), dim=-1).mean()
      grad_norm3 = torch.norm(grad3.reshape(grad3.shape[0], -1), dim=-1).mean()
      noise_norm3 = torch.norm(noise3.reshape(noise3.shape[0], -1), dim=-1).mean()

      grad_norm =(grad_norm1+grad_norm2+grad_norm3)/3.0
      noise_norm = (noise_norm1+noise_norm2+noise_norm3)/3.0

      step_size =  (2 * alpha)*((target_snr * noise_norm / grad_norm) ** 2 ) # 6

      x_mean = x_mean + step_size[:, None, None, None] * (grad1+grad2+grad3)/3.0 # 7

      x1 = x_mean + torch.sqrt(step_size * 2)[:, None, None, None] * noise1 # 7
      x2 = x_mean + torch.sqrt(step_size * 2)[:, None, None, None] * noise2 # 7
      x3 = x_mean + torch.sqrt(step_size * 2)[:, None, None, None] * noise3 # 7
    return x1,x2,x3, x_mean

@register_corrector(name='ald')
class AnnealedLangevinDynamics(Corrector):
  """The original annealed Langevin dynamics predictor in NCSN/NCSNv2.

  We include this corrector only for completeness. It was not directly used in our paper.
  """

  def __init__(self, sde, score_fn, snr, n_steps):
    super().__init__(sde, score_fn, snr, n_steps)
    if not isinstance(sde, sde_lib.VPSDE) \
        and not isinstance(sde, sde_lib.VESDE) \
        and not isinstance(sde, sde_lib.subVPSDE):
      raise NotImplementedError(f"SDE class {sde.__class__.__name__} not yet supported.")

  def update_fn(self, x, t):
    sde = self.sde
    score_fn = self.score_fn
    n_steps = self.n_steps
    target_snr = self.snr
    if isinstance(sde, sde_lib.VPSDE) or isinstance(sde, sde_lib.subVPSDE):
      timestep = (t * (sde.N - 1) / sde.T).long()
      alpha = sde.alphas.to(t.device)[timestep]
    else:
      alpha = torch.ones_like(t)

    std = self.sde.marginal_prob(x, t)[1]

    for i in range(n_steps):
      grad = score_fn(x, t)
      noise = torch.randn_like(x)
      step_size = (target_snr * std) ** 2 * 2 * alpha
      x_mean = x + step_size[:, None, None, None] * grad
      x = x_mean + noise * torch.sqrt(step_size * 2)[:, None, None, None]

    return x, x_mean


@register_corrector(name='none')
class NoneCorrector(Corrector):
  """An empty corrector that does nothing."""

  def __init__(self, sde, score_fn, snr, n_steps):
    pass

  def update_fn(self, x, t):
    return x, x


def shared_predictor_update_fn(x, t, sde, model, predictor, probability_flow, continuous):
  """A wrapper that configures and returns the update function of predictors."""
  score_fn = mutils.get_score_fn(sde, model, train=False, continuous=continuous)
  if predictor is None:
    # Corrector-only sampler
    predictor_obj = NonePredictor(sde, score_fn, probability_flow)
  else:
    predictor_obj = predictor(sde, score_fn, probability_flow)
  return predictor_obj.update_fn(x, t)


def shared_corrector_update_fn(x1,x2,x3,x_mean, t, sde, model, corrector, continuous, snr, n_steps):
  """A wrapper tha configures and returns the update function of correctors."""
  score_fn = mutils.get_score_fn(sde, model, train=False, continuous=continuous)
  if corrector is None:
    # Predictor-only sampler
    corrector_obj = NoneCorrector(sde, score_fn, snr, n_steps)
  else:
    corrector_obj = corrector(sde, score_fn, snr, n_steps)
  return corrector_obj.update_fn(x1,x2,x3,x_mean, t)


def get_pc_sampler(sde,sde_3channels, shape,shape_3channels,predictor, corrector, inverse_scaler, snr,
                   n_steps=1, probability_flow=False, continuous=False,
                   denoise=True, eps=1e-3, device='cuda'):
  """Create a Predictor-Corrector (PC) sampler.

  Args:
    sde: An `sde_lib.SDE` object representing the forward SDE.
    shape: A sequence of integers. The expected shape of a single sample.
    predictor: A subclass of `sampling.Predictor` representing the predictor algorithm.
    corrector: A subclass of `sampling.Corrector` representing the corrector algorithm.
    inverse_scaler: The inverse data normalizer.
    snr: A `float` number. The signal-to-noise ratio for configuring correctors.
    n_steps: An integer. The number of corrector steps per predictor update.
    probability_flow: If `True`, solve the reverse-time probability flow ODE when running the predictor.
    continuous: `True` indicates that the score model was continuously trained.
    denoise: If `True`, add one-step denoising to the final samples.
    eps: A `float` number. The reverse-time SDE and ODE are integrated to `epsilon` to avoid numerical issues.
    device: PyTorch device.

  Returns:
    A sampling function that returns samples and the number of function evaluations during sampling.
  """
  # Create predictor & corrector update functions
  predictor_update_fn = functools.partial(shared_predictor_update_fn,
                                          sde=sde,
                                          predictor=predictor,
                                          probability_flow=probability_flow,
                                          continuous=continuous)
  corrector_update_fn = functools.partial(shared_corrector_update_fn,
                                          sde=sde,
                                          corrector=corrector,
                                          continuous=continuous,
                                          snr=snr,
                                          n_steps=n_steps)
  predictor_update_fn_3channels = functools.partial(shared_predictor_update_fn,
                                                    sde=sde_3channels,
                                                    predictor=predictor,
                                                    probability_flow=probability_flow,
                                                    continuous=continuous)
  corrector_update_fn_3channels = functools.partial(shared_corrector_update_fn,
                                                    sde=sde_3channels,
                                                    corrector=corrector,
                                                    continuous=continuous,
                                                    snr=snr,
                                                    n_steps=n_steps)

  def create_mask(image, corner, size):
    """
    创建一个掩码，用于遮挡图像的特定部分，只保留指定的角落。
    参数:
    - image: 输入的张量
    - corner: 指定要保留的角落，值可以是 'right', 'left'。
    - size: 一个二元组，表示角落区域的大小 (width, height)。
    返回:
    - 一个掩码张量，大小与输入图像相同。
    """
    height, width = image.shape[-2:]
    # 创建全黑的掩码，确保掩码是正确的数据类型和大小
    mask = torch.ones((height, width), dtype=torch.uint8, device=image.device)
    # 根据指定的角落和大小设置掩码区域
    if corner == 'right':
      mask[:height, width - size[0]:width] = 0
    elif corner == 'left':
      mask[:height, :size[0]] = 0
    return mask

  def save_image(x, iteration, suffix):
    """保存前三个通道、后三个通道和加权平均后的图像"""
    # 提取前三个通道（0相位）
    if x.shape[1] == 6:
      phase0 = x[0, :3, :, :].permute(1, 2, 0).cpu().numpy()
      # 提取后三个通道（0.5pi相位）
      phase05 = x[0, 3:, :, :].permute(1, 2, 0).cpu().numpy()
      # 截断超出范围的值
      #phase0 = np.clip(phase0, 0, 1)
      #phase05 = np.clip(phase05, 0, 1)
      # 调整通道顺序
      phase0_bgr = np.stack((phase0[:, :, 2], phase0[:, :, 1], phase0[:, :, 0]), axis=2)
      phase05_bgr = np.stack((phase05[:, :, 2], phase05[:, :, 1], phase05[:, :, 0]), axis=2)
      # 保存为 .png 文件
      cv2.imwrite(f"iter_{iteration + 1}_{suffix}_phase0.png", (phase0_bgr * 255).astype(np.uint8))
      cv2.imwrite(f"iter_{iteration + 1}_{suffix}_phase05.png", (phase05_bgr * 255).astype(np.uint8))
      # # 保存为 .mat 文件
      # io.savemat(f"iter_{iteration + 1}_{suffix}_phase0.mat", {"data": phase0_clipped})
      # io.savemat(f"iter_{iteration + 1}_{suffix}_phase05.mat", {"data": phase05_clipped})
    elif x.shape[1] == 3:
      image=x[0, :, :, :].permute(1, 2, 0).cpu().numpy()
      #image=np.clip(image, 0, 1)
      image_ = np.stack((image[:, :, 2], image[:, :, 1], image[:, :, 0]), axis=2)
      cv2.imwrite(f"iter_{iteration + 1}_{suffix}_img.png", (image_ * 255).astype(np.uint8))

  def pc_sampler(model,model_3channels,data,mask1,mask2,data_ob1,data_ob2,width=96):
    """ The PC sampler funciton.

    Args:
      model: A score model.
    Returns:
      Samples, number of function evaluations.
    """

    with (torch.no_grad()):
      # Initial sample
      shape = (1, 6, 256, 256)
      x_mean = sde.prior_sampling(shape).to(device)    #(1,3,256,256)
      # save_image(x_mean,0,"prior")
      x1=x_mean
      x2=x_mean
      x3=x_mean
      timesteps = torch.linspace(sde.T, eps, sde.N, device=device)
      psnr_max=0
      ssim_max=0
      ssim = 0
      psnr = 0
      ssim_lst = []
      psnr_lst = []
######################################################################################
      ##########DC保真掩码########
      mask_width = 256 - width
      MASK_1 = create_mask(x_mean[0, 0, :, :], 'right', (mask_width, 256))
      MASK_2 = create_mask(x_mean[0, 3, :, :], 'left', (mask_width, 256))

      last_img = 0
      best_img = 0

      break_epochs = {
        1:100,
        64: 100,
        86: 150,
        96: 200,
        128: 350,
      }
      for i in range(500):
        #######################################################################编码域模型，未采样数据恢复##################################################################
        t = timesteps[i]
        vec_t = torch.ones(shape[0], device=t.device) * t
        ########################predictor_update#######################
        x, x_mean = predictor_update_fn(x_mean.float(), vec_t, model=model)

        #x: A PyTorch tensor of the next state.
        #x_mean: A PyTorch tensor. The next state without random noise. Useful for denoising.

        data_ob_first1=data_ob1.permute(2,0,1).unsqueeze(0)    #(3,256,256)
        data_ob_first2=data_ob2.permute(2,0,1).unsqueeze(0)

        masked_data_mean1, std = sde.marginal_prob(data_ob_first1, vec_t)
        masked_data_mean2, std = sde.marginal_prob(data_ob_first2, vec_t)

        forward_noise_0,forward_noise_1,forward_noise_2=fza_mask_forward1(torch.randn_like(x_mean))      #(256,256)
        noise_result1=torch.stack((forward_noise_0,forward_noise_1,forward_noise_2),dim=0).unsqueeze(0)   #(1,3,256,256)
        masked_data1 = masked_data_mean1 +  noise_result1* std[:, None, None, None]

        forward_noise_0,forward_noise_1,forward_noise_2=fza_mask_forward2(torch.randn_like(x_mean))      #(256,256)
        noise_result2=torch.stack((forward_noise_0,forward_noise_1,forward_noise_2),dim=0).unsqueeze(0)   #(1,3,256,256)
        masked_data2 = masked_data_mean2 +  noise_result2* std[:, None, None, None]


        a=1
        b=1
        c=1
        d=1

        e=1
        f=1
        g=1
        h=1

        #############################x_mean#################################
        x_channel_0 = e * (x_mean[0, 0, :, :] * MASK_1) + a*(masked_data1[0, 0, :, :] * (1 - MASK_1))
        x_channel_1 = e * (x_mean[0, 1, :, :] * MASK_1) + a*(masked_data1[0, 1, :, :] * (1 - MASK_1))
        x_channel_2 = e * (x_mean[0, 2, :, :] * MASK_1) + a*(masked_data1[0, 2, :, :] * (1 - MASK_1))
        x_channel_3 = f * (x_mean[0, 3, :, :] * MASK_2) + b*(masked_data2[0, 0, :, :] * (1 - MASK_2))
        x_channel_4 = f * (x_mean[0, 4, :, :] * MASK_2) + b*(masked_data2[0, 1, :, :] * (1 - MASK_2))
        x_channel_5 = f * (x_mean[0, 5, :, :] * MASK_2) + b*(masked_data2[0, 2, :, :] * (1 - MASK_2))

        x_mean=torch.stack((x_channel_0,x_channel_1,x_channel_2,x_channel_3,x_channel_4,x_channel_5),dim=0).unsqueeze(0)
        if i == 100:
            save_image(x_mean, 100, "iter100_combined")
        #############################x#################################
        x_channel_0 = g * (x_mean[0, 0, :, :] * MASK_1) + c*(masked_data_mean1[0, 0, :, :] * (1 - MASK_1))
        x_channel_1 = g * (x_mean[0, 1, :, :] * MASK_1) + c*(masked_data_mean1[0, 1, :, :] * (1 - MASK_1))
        x_channel_2 = g * (x_mean[0, 2, :, :] * MASK_1) + c*(masked_data_mean1[0, 2, :, :] * (1 - MASK_1))
        x_channel_3 = h * (x_mean[0, 3, :, :] * MASK_2) + d*(masked_data_mean2[0, 0, :, :] * (1 - MASK_2))
        x_channel_4 = h * (x_mean[0, 4, :, :] * MASK_2) + d*(masked_data_mean2[0, 1, :, :] * (1 - MASK_2))
        x_channel_5 = h * (x_mean[0, 5, :, :] * MASK_2) + d*(masked_data_mean2[0, 2, :, :] * (1 - MASK_2))

        x=torch.stack((x_channel_0,x_channel_1,x_channel_2,x_channel_3,x_channel_4,x_channel_5),dim=0).unsqueeze(0)

        x1,x2,x3=x,x,x
        ########################corrector_update#########################
        x1,x2,x3, x_mean = corrector_update_fn(x1.float(),x2.float(),x3.float(),x_mean.float(), vec_t, model=model)


        #############################x_mean#################################
        x_channel_0 = e * (x_mean[0, 0, :, :] * MASK_1) + a*(masked_data1[0, 0, :, :] * (1 - MASK_1))
        x_channel_1 = e * (x_mean[0, 1, :, :] * MASK_1) + a*(masked_data1[0, 1, :, :] * (1 - MASK_1))
        x_channel_2 = e * (x_mean[0, 2, :, :] * MASK_1) + a*(masked_data1[0, 2, :, :] * (1 - MASK_1))
        x_channel_3 = f * (x_mean[0, 3, :, :] * MASK_2) + b*(masked_data2[0, 0, :, :] * (1 - MASK_2))
        x_channel_4 = f * (x_mean[0, 4, :, :] * MASK_2) + b*(masked_data2[0, 1, :, :] * (1 - MASK_2))
        x_channel_5 = f * (x_mean[0, 5, :, :] * MASK_2) + b*(masked_data2[0, 2, :, :] * (1 - MASK_2))

        x_mean=torch.stack((x_channel_0,x_channel_1,x_channel_2,x_channel_3,x_channel_4,x_channel_5),dim=0).unsqueeze(0)

        #############################x#################################
        x_channel_0 = g * (x_mean[0, 0, :, :] * MASK_1) + c*(masked_data_mean1[0, 0, :, :] * (1 - MASK_1))
        x_channel_1 = g * (x_mean[0, 1, :, :] * MASK_1) + c*(masked_data_mean1[0, 1, :, :] * (1 - MASK_1))
        x_channel_2 = g * (x_mean[0, 2, :, :] * MASK_1) + c*(masked_data_mean1[0, 2, :, :] * (1 - MASK_1))
        x_channel_3 = h * (x_mean[0, 3, :, :] * MASK_2) + d*(masked_data_mean2[0, 0, :, :] * (1 - MASK_2))
        x_channel_4 = h * (x_mean[0, 4, :, :] * MASK_2) + d*(masked_data_mean2[0, 1, :, :] * (1 - MASK_2))
        x_channel_5 = h * (x_mean[0, 5, :, :] * MASK_2) + d*(masked_data_mean2[0, 2, :, :] * (1 - MASK_2))

        x=torch.stack((x_channel_0,x_channel_1,x_channel_2,x_channel_3,x_channel_4,x_channel_5),dim=0).unsqueeze(0)

        x_0=x[0, 0, :, :]
        x_1=x[0, 1, :, :]
        x_2=x[0, 2, :, :]
        x_3=x[0, 3, :, :]
        x_4=x[0, 4, :, :]
        x_5=x[0, 5, :, :]
        # x_0 = tvdenoise(x[0, 0, :, :], 10, 2)
        # x_1 = tvdenoise(x[0, 1, :, :], 10, 2)
        # x_2 = tvdenoise(x[0, 2, :, :], 10, 2)
        # x_3 = tvdenoise(x[0, 3, :, :], 10, 2)
        # x_4 = tvdenoise(x[0, 4, :, :], 10, 2)
        # x_5 = tvdenoise(x[0, 5, :, :], 10, 2)
        x = torch.stack((x_0, x_1, x_2, x_3, x_4, x_5), dim=0).unsqueeze(0)
        ########FZA逆变换，转化为空间域数据########
        # x[0, 0, :, :] = tvdenoise(x[0, 0, :, :], 10, 2)
        # x[0, 1, :, :] = tvdenoise(x[0, 1, :, :], 10, 2)
        # x[0, 2, :, :] = tvdenoise(x[0, 2, :, :], 10, 2)
        # x[0, 3, :, :] = tvdenoise(x[0, 3, :, :], 10, 2)
        # x[0, 4, :, :] = tvdenoise(x[0, 4, :, :], 10, 2)
        # x[0, 5, :, :] = tvdenoise(x[0, 5, :, :], 10, 2)

        X_0 = backward(x[0, 0, :, :], mask1)
        X_1 = backward(x[0, 1, :, :], mask1)
        X_2 = backward(x[0, 2, :, :], mask1)
        X_3 = backward(x[0, 3, :, :], mask2)
        X_4 = backward(x[0, 4, :, :], mask2)
        X_5 = backward(x[0, 5, :, :], mask2)

        X_0 = tvdenoise(X_0, 10, 3)
        X_1 = tvdenoise(X_1, 10, 3)
        X_2 = tvdenoise(X_2, 10, 3)
        X_3 = tvdenoise(X_3, 10, 3)
        X_4 = tvdenoise(X_4, 10, 3)
        X_5 = tvdenoise(X_5, 10, 3)

        #######归一化，去除负值########
        X_0 = (X_0 - X_0.min()) / (X_0.max() - X_0.min())
        X_1 = (X_1 - X_1.min()) / (X_1.max() - X_1.min())
        X_2 = (X_2 - X_2.min()) / (X_2.max() - X_2.min())
        X_3 = (X_3 - X_3.min()) / (X_3.max() - X_3.min())
        X_4 = (X_4 - X_4.min()) / (X_4.max() - X_4.min())
        X_5 = (X_5 - X_5.min()) / (X_5.max() - X_5.min())
        X = torch.stack((X_0, X_1, X_2, X_3, X_4, X_5), dim=0).unsqueeze(0)
        #########################output#####################
        x_mean_save=X.cpu().numpy()
        x_mean_save_cv=(a*x_mean_save[0,:3,:,:].transpose(1,2,0)+b*x_mean_save[0,3:,:,:].transpose(1,2,0))/(a+b)
        data_ori = data[0, :, :, :].cpu().numpy().transpose(1, 2, 0)
        # x_mean_save_cv[57:200, 57:200, :] = (x_mean_save_cv[57:200, 57:200, :] - x_mean_save_cv[57:200, 57:200, :].min()) / (
        #          x_mean_save_cv[57:200, 57:200, :].max() - x_mean_save_cv[57:200, 57:200, :].min())
        x_mean_save_cv = (x_mean_save_cv - x_mean_save_cv.min()) / (x_mean_save_cv.max() - x_mean_save_cv.min())
        # x_mean_save_cv[:57, :, :] = 0
        # x_mean_save_cv[200:, :, :] = 0
        # x_mean_save_cv[:, :57, :] = 0
        # x_mean_save_cv[:, 200:, :] = 0
        data_ori = (data_ori - data_ori.min()) / (data_ori.max() - data_ori.min())
        x_mean_save_cv = np.clip(x_mean_save_cv, 0, 1)
        data_ori = np.clip(data_ori, 0, 1)
        psnr = compare_psnr(np.abs(x_mean_save_cv) * 255, np.abs(data_ori) * 255, data_range=255)
        # ssim = compare_ssim(np.abs(x_mean_save_cv), np.abs(data_ori), multichannel=True, data_range=1)
        h, w = x_mean_save_cv.shape[:2]
        win_size = min(7, h, w)
        win_size = win_size if win_size % 2 else win_size - 1
        if win_size < 3:
            win_size = 3
        ssim = compare_ssim(np.abs(x_mean_save_cv), np.abs(data_ori),
                        win_size=win_size,
                        channel_axis=-1,  # 多通道
                        data_range=1)

        psnr_lst.append(psnr)
        ssim_lst.append(ssim)
        print('itertions:', i, 'psnr:', psnr, 'ssim:', ssim)


        if i == break_epochs[width]:
          last_img = np.stack((x_mean_save_cv[:, :, 2], x_mean_save_cv[:, :, 1], x_mean_save_cv[:, :, 0]), axis=2)
          cv2.imwrite(f"iter{i}_reconstruction.png", last_img * 255)
          break
        if psnr > psnr_max :
          psnr_max = psnr
          print('psnr_max', psnr_max)
          x_mean_save_best = np.stack((x_mean_save_cv[:, :, 2], x_mean_save_cv[:, :, 1], x_mean_save_cv[:, :, 0]), axis=2)
          best_img = x_mean_save_best
          cv2.imwrite(f"CPFF_best_reconstruction.png", x_mean_save_best * 255)
        if ssim > ssim_max:
          ssim_max = ssim
          print('ssim_max', ssim_max)


#############################################相位融合，转化为三通道数据#################################################
        phase0_rgb = torch.stack([X_0, X_1, X_2], dim=0).unsqueeze(0)  # 0相位RGB
        phase05_rgb = torch.stack([X_3, X_4, X_5], dim=0).unsqueeze(0)  # 0.5π相位RGB
        x_mean_3channels = (a * phase0_rgb + b * phase05_rgb) / (a + b)
#######################################################################空间域模型，去噪##################################################################
        vec_t_3channels = torch.ones(shape_3channels[0], device=t.device) * t
        ########################predictor_update#######################
        x_3channels, x_mean_3channels = predictor_update_fn_3channels(x_mean_3channels, vec_t_3channels, model=model_3channels)
        # x: A PyTorch tensor of the next state.
        # x_mean: A PyTorch tensor. The next state without random noise. Useful for denoising.

        data_ob_first1_3channels = data_ob1.permute(2, 0, 1).unsqueeze(0)  # (3,256,256)
        data_ob_first2_3channels = data_ob2.permute(2, 0, 1).unsqueeze(0)

        masked_data_mean1_3channels, std_3channels = sde_3channels.marginal_prob(data_ob_first1_3channels, vec_t)
        masked_data_mean2_3channels, std_3channels = sde_3channels.marginal_prob(data_ob_first2_3channels, vec_t)

        forward_noise_0_3channels, forward_noise_1_3channels, forward_noise_2_3channels = fza_mask_forward1(torch.randn_like(x_mean_3channels))  # (256,256)
        noise_result1_3channels = torch.stack((forward_noise_0_3channels, forward_noise_1_3channels, forward_noise_2_3channels), dim=0).unsqueeze(
          0)  # (1,3,256,256)
        masked_data1_3channels = masked_data_mean1_3channels + noise_result1_3channels * std[:, None, None, None]

        forward_noise_0_3channels, forward_noise_1_3channels, forward_noise_2_3channels = fza_mask_forward2(torch.randn_like(x_mean_3channels))  # (256,256)
        noise_result2_3channels = torch.stack((forward_noise_0_3channels, forward_noise_1_3channels, forward_noise_2_3channels), dim=0).unsqueeze(
          0)  # (1,3,256,256)
        masked_data2_3channels = masked_data_mean2_3channels + noise_result2_3channels * std[:, None, None, None]

        x4, x5, x6 = x_3channels, x_3channels, x_3channels
        ########################corrector_update#########################
        x4, x5, x6, x_mean_3channels = corrector_update_fn_3channels(x4, x5, x6, x_mean_3channels, vec_t_3channels, model=model_3channels)

        x_3channels=x_mean_3channels
        #######TV平滑去噪#######
        x_0 = tvdenoise(x_3channels[0, 0, :, :], 10, 2)
        x_1 = tvdenoise(x_3channels[0, 1, :, :], 10, 2)
        x_2 = tvdenoise(x_3channels[0, 2, :, :], 10, 2)

        x_3channels = torch.stack((x_0, x_1, x_2), dim=0).unsqueeze(0)
        ####################FZA双相位编码#####################
        re_encoded_0 = torch.stack([
          forward(x_3channels[0, 0, :, :], mask1),
          forward(x_3channels[0, 1, :, :], mask1),
          forward(x_3channels[0, 2, :, :], mask1)
        ], dim=0).unsqueeze(0)

        re_encoded_05 = torch.stack([
          forward(x_3channels[0, 0, :, :], mask2),
          forward(x_3channels[0, 1, :, :], mask2),
          forward(x_3channels[0, 2, :, :], mask2)
        ], dim=0).unsqueeze(0)

        re_encoded_0 = (re_encoded_0 - re_encoded_0.min()) / (re_encoded_0.max() - re_encoded_0.min())
        re_encoded_05 = (re_encoded_05 - re_encoded_05.min()) / (re_encoded_05.max() - re_encoded_05.min())
        x_mean = torch.cat((re_encoded_0, re_encoded_05), dim=1)  # 沿通道维度拼接
        #x_mean = (x_mean - x_mean.min()) / (x_mean.max() - x_mean.min())

        # if i in [10,100,200,300,499]:
        #   save_image(x_mean, i, "recode")

      print('psnr_max:', psnr_max, 'ssim_max:', ssim_max)
      # # 最佳结果
      # return best_img, psnr_max, ssim_max, psnr_lst, ssim_lst

      #最后结果
      return last_img, psnr, ssim, psnr_lst, ssim_lst
  return pc_sampler


  


