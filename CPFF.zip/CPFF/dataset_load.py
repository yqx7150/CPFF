from torch.utils.data import DataLoader, Subset,Dataset
import torchvision.transforms as transforms
import torchvision.transforms as T
import cv2
import glob
import matplotlib.pyplot as plt
import numpy as np
# class LoadDataset(Dataset):
#     def __init__(self,file_list,transform=None):
#         self.files = glob.glob(file_list+ '/*.png')  #church
#         '''
#         self.folders = glob.glob(file_list+ '/*')
#         self.files=[]
#         for folder in self.folders:
#             for f in glob.glob(folder+'/*.png'):
#                 self.files.append(f)
#         '''
#
#
#         self.transform = transform
#         self.to_tensor = T.ToTensor()
#     def __len__(self):
#         return len(self.files)
#     def __getitem__(self,index):
#         img = cv2.imread(self.files[index], 3)
#         img = cv2.resize(img, (256, 256))
#         im = img[:,:,:3]/255
#         im=np.stack((im[:,:,2],im[:,:,1],im[:,:,0],im[:,:,2],im[:,:,1],im[:,:,0]),axis=2)
#         '''
#         im_r_fft=np.fft.fftshift(np.fft.fft2(np.fft.fftshift(im[:,:,0])))
#         im_g_fft=np.fft.fftshift(np.fft.fft2(np.fft.fftshift(im[:,:,1])))
#         im_b_fft=np.fft.fftshift(np.fft.fft2(np.fft.fftshift(im[:,:,2])))
#         img_all=np.stack((np.real(im_r_fft),np.imag(im_r_fft),np.real(im_g_fft),np.imag(im_g_fft),np.real(im_b_fft),np.imag(im_b_fft)),axis=2)
#         '''
#         return im.transpose(2,0,1)  #img_all.transpose(2,0,1)
class LoadDataset(Dataset):
    def __init__(self, file_list, transform=None):
        # 确保文件列表是按顺序排列的
        self.files = sorted(glob.glob(file_list + '/*.png'))
        if len(self.files) != 19800:
            raise ValueError("数据集文件数量必须为19800张图片！")

        self.transform = transform
        self.to_tensor = T.ToTensor()

    def __len__(self):
        return len(self.files) // 2  # 每对图片算一个样本，所以长度是文件数量的一半

    def __getitem__(self, index):
        # 加载第index对图片
        img_ob1_path = self.files[index]  # 前9900张图片
        img_ob2_path = self.files[index + 9900]  # 后9900张图片

        # 读取图片
        img_ob1 = cv2.imread(img_ob1_path, 3)
        img_ob2 = cv2.imread(img_ob2_path, 3)

        # 调整图片大小
        img_ob1 = cv2.resize(img_ob1, (256, 256))
        img_ob2 = cv2.resize(img_ob2, (256, 256))

        # 归一化到[0,1]
        img_ob1 = img_ob1[:, :, :3] / 255
        img_ob2 = img_ob2[:, :, :3] / 255

        # 通道堆叠
        # im = np.stack((img_ob1[:, :, 2], img_ob2[:, :, 2], img_ob1[:, :, 1],
        #                img_ob2[:, :, 1], img_ob1[:, :, 0], img_ob2[:, :, 0]), axis=2)
        # # R R G G B B
        im = np.stack((img_ob1[:, :, 2], img_ob1[:, :, 1], img_ob1[:, :, 0],
                       img_ob2[:, :, 2], img_ob2[:, :, 1], img_ob2[:, :, 0]), axis=2)
        #R G B R G B
        # 转换为CHW格式（通道在前）
        im = im.transpose(2, 0, 1)

        return im
