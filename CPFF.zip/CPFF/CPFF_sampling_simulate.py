import matplotlib
import numpy as np
import numpy as np
import numpy as np
import pandas as pd
import seaborn as sns
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_gan as tfgan
import torch
import tqdm

from losses import get_optimizer
from models.ema import ExponentialMovingAverage
from utils import restore_checkpoint

sns.set(font_scale=2)
sns.set(style="whitegrid")
import cv2
from models import utils as mutils
import CPFF_reconstruction_simulate
from sde_lib import VESDE
from CPFF_reconstruction_simulate import (ReverseDiffusionPredictor,
                                          LangevinCorrector)
import datasets
import scipy.io as io
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import time


def main(ckpt_filename, ckpt_filename_3channels, GT, I_phase0, I_phase1, width):
  time_begin = time.time()
  # @title Load the score-based model
  ####################################################################moddel_6channels#######################################################################
  sde = 'VESDE' #@param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
  if sde.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_6channels as configs1
    config1 = configs1.get_config()
    sde = VESDE(sigma_min=config1.model.sigma_min, sigma_max=config1.model.sigma_max, N=config1.model.num_scales)
    sampling_eps = 1e-5

  batch_size =  1 #64#@param {"type":"integer"}
  config1.training.batch_size = batch_size
  config1.eval.batch_size = batch_size

  random_seed = 0 #@param {"type": "integer"}

  sigmas = mutils.get_sigmas(config1)
  scaler = datasets.get_data_scaler(config1)
  inverse_scaler = datasets.get_data_inverse_scaler(config1)
  score_model = mutils.create_model(config1)

  optimizer = get_optimizer(config1, score_model.parameters())
  ema = ExponentialMovingAverage(score_model.parameters(),
                                 decay=config1.model.ema_rate)
  state = dict(step=0, optimizer=optimizer,
               model=score_model, ema=ema)

  state = restore_checkpoint(ckpt_filename, state, config1.device)

  ema.copy_to(score_model.parameters())
  ####################################################################moddel_3channels#######################################################################
  sde_3channels = 'VESDE' #@param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
  if sde_3channels.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_3channels as configs2

    config2 = configs2.get_config_3channels()
    sde_3channels = VESDE(sigma_min=config2.model.sigma_min, sigma_max=config2.model.sigma_max, N=config2.model.num_scales)
    sampling_eps = 1e-5

  batch_size =  1 #64#@param {"type":"integer"}
  config2.training.batch_size = batch_size
  config2.eval.batch_size = batch_size

  random_seed = 0 #@param {"type": "integer"}

  sigmas_3channels = mutils.get_sigmas(config2)
  scaler_3channels = datasets.get_data_scaler(config2)
  inverse_scaler_3channels = datasets.get_data_inverse_scaler(config2)
  score_model_3channels = mutils.create_model(config2)

  optimizer_3channels = get_optimizer(config2, score_model_3channels.parameters())
  ema_3channels = ExponentialMovingAverage(score_model_3channels.parameters(),
                                           decay=config2.model.ema_rate)
  state_3channels = dict(step=0, optimizer=optimizer_3channels,
                         model=score_model_3channels, ema=ema_3channels)

  state_3channels = restore_checkpoint(ckpt_filename_3channels, state_3channels, config2.device)

  ema_3channels.copy_to(score_model_3channels.parameters())
  ###################################################################################################################################################
  #@title PC inpainting
  predictor = ReverseDiffusionPredictor #@param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
  corrector = LangevinCorrector #@param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}
  predictor_3channels = ReverseDiffusionPredictor #@param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
  corrector_3channels = LangevinCorrector #@param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}

  snr = 0.16 #@param {"type": "number"}
  n_steps = 1 #@param {"type": "integer"}
  probability_flow = False #@param {"type": "boolean"}

  psnr_result=[ ]
  ssim_result=[ ]
  for j in range(0,1,1):

    img = io.loadmat(GT)['Im']
    img_ob1 = io.loadmat(I_phase0)['ob']
    img_ob2 = io.loadmat(I_phase1)['ob']


    img = torch.from_numpy(img).permute(2,0,1).unsqueeze(0).cuda()     #tensor:(1,3,256,256)

    img_ob1=torch.from_numpy(img_ob1).cuda()                         #######################
    img_ob2=torch.from_numpy(img_ob2).cuda()

    dp=0.014#0.0038*3
    di=3#2
    z1=300#400
    r1=0.23#0.3


    M=di/z1
    ri=(1+M)*r1

    NX,NY=256,256

    fu_max,fv_max=0.5/dp,0.5/dp
    du,dv=2*fu_max/NX,2*fv_max/NY
    u,v=np.mgrid[-fu_max:fu_max:du,-fv_max:fv_max:dv]
    u=u.T
    v=v.T
    H1=1j*(np.exp(-1j*(np.dot(np.pi,ri**2))*(u**2+v**2)))
    # H2 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2)))
    H2=1j*(np.exp(-1j*(np.dot(np.pi,ri**2))*(u**2+v**2)+1j*0.5*np.pi))


    H1=np.array(H1,dtype=np.complex128)
    H2=np.array(H2,dtype=np.complex128)

    for i in range(1):
      print('##################'+str(i)+'#######################')

      img_size = config1.data.image_size                 #256
      channels = config1.data.num_channels               #3
      shape = (batch_size, channels, img_size, img_size)   #(1,6,256,256)
      shape_3channels = (batch_size, channels, img_size, img_size)  # (1,6,256,256)

      sampling_fn = CPFF_reconstruction_simulate.get_pc_sampler(sde, sde_3channels, shape, shape_3channels, predictor,
                                                                    corrector, inverse_scaler, snr, n_steps=n_steps,
                                                                    probability_flow=probability_flow,
                                                                    continuous=config1.training.continuous,
                                                                    eps=sampling_eps, device=config1.device)

      x_3channels, a, b, psnr_lst, ssim_lst= sampling_fn(score_model, score_model_3channels, img, H1, H2, img_ob1, img_ob2, width=width)

      x_3channels_min=x_3channels.min()
      x_3channels_max=x_3channels.max()
      x_3channels= (x_3channels - x_3channels_min) / (x_3channels_max - x_3channels_min)

      cv2.imwrite('./Reconstructed_img.png', x_3channels * 255)
      time_end = time.time()
      print('time:',time_end-time_begin)



if __name__ == '__main__':
    ckpt_filename = "./checkpoints/6channels_checkpoint_25.pth" #(9:(20.2,0.5)
    ckpt_filename_3channels = "./checkpoints/3channels_checkpoint_2.pth" #(9:(20.2,0.5)
    # GT = './1205/0_original.mat'
    # I_phase0 = './1205/0_Phase0_cut96.mat'
    # I_phase0 = './test_img/1215test.mat'
    # I_phase1 = './test_img/1215test.mat'
    GT = './test_imgs/input/img2/original.mat'
    I_phase0 = './test_imgs/input/img2/processed_0.mat'
    I_phase1 = './test_imgs/input/img2/processed_50.mat'
    width = 96
    main(ckpt_filename, ckpt_filename_3channels, GT, I_phase0, I_phase1, width)




